package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation cho 1 tick.
 *
 * HEAD sendMovementPackets : arm(hitVec) → yaw/pitch snap theo lưới chuột, movement packet mang góc này
 * END_CLIENT_TICK          : interact (rail/cart) → disarm() trả góc gốc
 *
 * Chỉ arm khi tick đó thật sự sẽ đặt block. Không arm lúc chờ → không có packet rotation thừa.
 * Chỉ dùng trên main thread.
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static boolean armed      = false;
    private static float   savedYaw   = 0f;
    private static float   savedPitch = 0f;
    private static float   armedYaw   = 0f;

    public static boolean isArmed() { return armed; }

    public static void arm(ClientPlayerEntity player, Vec3d hitVec) {
        if (armed || player == null) return;
        savedYaw   = player.getYaw();
        savedPitch = player.getPitch();
        applyRaw(player, snapToMouseGrid(player, calcRotationFromEye(player.getEyePos(), hitVec)));
        armedYaw = player.getYaw();
        armed = true;
    }

    /** Trả góc gốc. An toàn khi gọi nhiều lần hoặc player == null. */
    public static void disarm(ClientPlayerEntity player) {
        if (armed && player != null) applyRaw(player, new float[]{ savedYaw, savedPitch });
        armed = false;
    }

    public static void reset() { armed = false; }

    /** Yaw thật của camera trước khi arm (dùng để bù input). */
    public static float realYaw()   { return savedYaw; }
    /** Yaw đang gửi trong movement packet khi armed. */
    public static float silentYaw() { return armedYaw; }

    // ─── Mouse grid ──────────────────────────────────────────────────────────

    /** Bước góc nhỏ nhất chuột vanilla tạo ra ở sensitivity hiện tại. */
    public static double mouseStep() {
        double sens = net.minecraft.client.MinecraftClient.getInstance()
            .options.getMouseSensitivity().getValue();
        double f = sens * 0.6 + 0.2;
        return f * f * f * 8.0 * 0.15;
    }

    /** Snap góc đích về lưới chuột, delta tính từ góc hiện tại của player. */
    public static float[] snapToMouseGrid(ClientPlayerEntity player, float[] rot) {
        double step   = mouseStep();
        double curYaw = player.getYaw();
        double curPit = player.getPitch();

        double dYaw   = wrap180(rot[0] - curYaw);
        double dPitch = rot[1] - curPit;

        double yaw   = curYaw + Math.round(dYaw   / step) * step;
        double pitch = curPit + Math.round(dPitch / step) * step;

        double maxPitch = Math.floor(90.0 / step) * step;
        pitch = Math.max(-maxPitch, Math.min(maxPitch, pitch));

        return new float[]{ (float) yaw, (float) pitch };
    }

    private static double wrap180(double deg) {
        return ((deg % 360.0) + 540.0) % 360.0 - 180.0;
    }

    // ─── Math utils ──────────────────────────────────────────────────────────

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    public static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];
        player.bodyYaw = rot[0];
    }
}
