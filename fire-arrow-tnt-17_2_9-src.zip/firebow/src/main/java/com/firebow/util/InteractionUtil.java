package com.firebow.util;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * InteractionUtil v9.
 *
 * - Chỉ interact khi RotationUtil đang armed (góc đã nằm trong movement packet tick này).
 * - Đổi slot luôn gửi UpdateSelectedSlotC2SPacket, để server biết item đang cầm.
 * - Không interact khi đang giữ item dùng (cung): đổi slot sẽ hủy use item.
 */
public final class InteractionUtil {
    private InteractionUtil() {}

    public enum Result { SENT, NOT_READY, INVALID }

    /** Có thể đặt rail ngay tick này không (không cần biết góc, chỉ kiểm tra điều kiện). */
    public static boolean railReady(MinecraftClient mc, ClientPlayerEntity p, BlockPos railPos) {
        if (mc.world == null || mc.interactionManager == null) return false;
        if (p.isUsingItem() || !inReach(p, railPos))          return false;
        if (!mc.world.getBlockState(railPos).isAir())         return false;
        return PlacementCalc.isSolidGround(mc.world, railPos.down());
    }

    /** Có thể đặt cart lên rail ngay tick này không. */
    public static boolean cartReady(MinecraftClient mc, ClientPlayerEntity p, BlockPos railPos) {
        if (mc.world == null || mc.interactionManager == null) return false;
        if (p.isUsingItem() || !inReach(p, railPos))          return false;
        var s = mc.world.getBlockState(railPos);
        return s.isOf(Blocks.RAIL) || s.isOf(Blocks.POWERED_RAIL);
    }

    public static Result executeRail(MinecraftClient mc, BlockPos railPos, int railSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) return Result.INVALID;

        BlockPos ground = railPos.down();
        if (!mc.world.getBlockState(railPos).isAir())       return Result.INVALID;
        if (!PlacementCalc.isSolidGround(mc.world, ground)) return Result.INVALID;
        if (p.isUsingItem() || !inReach(p, railPos))        return Result.NOT_READY;
        if (!RotationUtil.isArmed())                        return Result.NOT_READY;

        Vec3d hitVec = RotationUtil.calcHitVec(ground, Direction.UP);
        int origSlot = p.getInventory().selectedSlot;

        selectSlot(mc, p, railSlot);
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, ground, false));
        selectSlot(mc, p, origSlot);
        return Result.SENT;
    }

    public static boolean placeCartDirect(MinecraftClient mc, BlockPos railPos, int cartSlot) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return false;
        if (p.isUsingItem() || !inReach(p, railPos))    return false;
        if (!RotationUtil.isArmed())                    return false;

        Vec3d hitVec = RotationUtil.calcHitVec(railPos, Direction.UP);
        int origSlot = p.getInventory().selectedSlot;

        selectSlot(mc, p, cartSlot);
        p.swingHand(Hand.MAIN_HAND);
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
            new BlockHitResult(hitVec, Direction.UP, railPos, false));
        selectSlot(mc, p, origSlot);
        return true;
    }

    /** Đổi slot phía client và báo server. Không gửi thì server vẫn nghĩ đang cầm item cũ. */
    private static void selectSlot(MinecraftClient mc, ClientPlayerEntity p, int slot) {
        p.getInventory().selectedSlot = slot;
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
    }

    public static boolean inReach(ClientPlayerEntity p, BlockPos pos) {
        return p.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= 4.5 * 4.5;
    }
}
